# youtube-channel-site
A project for my youtube channel, i wanted a website for my youtube channel, so i decided to create a website for it.

### Prerequisites

You will need the follow technologies.

XAMPP V 3.2.2 and PHP 7.2.28.

### Installing

Step 1

Install PHP 7.2.28 on your machine

Step 2

Install XAMPP V 3.2.2
 
## Authors

* **Gustavo Specht** - *Initial work* - [guspecht](https://github.com/guspecht/)

