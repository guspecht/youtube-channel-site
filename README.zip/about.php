<!-- Require header -->
<?php  require './resources/templates/header.php';?>

<!-- Start ABout -->
<section id="about">
    <div class="container">
        <div class="block">
            <h1>About</h1>
            <p>I'm a Fortnite player who is going to help you guys with all Week Challenges, Fortnite Secrets and how to get better in Fortnite, also I record gameplay!</p>
        </div>
    </div>
</section>
<!-- End About -->

<!-- Require footer -->
<?php  require './resources/templates/footer.php';?>